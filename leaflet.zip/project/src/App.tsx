import React from 'react';
import { MapPin } from 'lucide-react';
import Map from './components/Map';

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm h-16">
        <div className="max-w-7xl mx-auto px-4 h-full flex items-center">
          <div className="flex items-center space-x-2">
            <MapPin className="w-6 h-6 text-blue-600" />
            <h1 className="text-xl font-semibold text-gray-900">Interactive Map Explorer</h1>
          </div>
        </div>
      </header>
      
      <main>
        <Map />
      </main>
    </div>
  );
}

export default App;