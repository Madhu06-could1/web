import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { Icon } from 'leaflet';
import { MapPin } from 'lucide-react';

// Sample points of interest data
const pointsOfInterest = [
  {
    id: 1,
    name: "Central Park",
    position: [40.785091, -73.968285],
    description: "An urban oasis in the heart of New York City",
    image: "https://images.unsplash.com/photo-1570168007204-dfb528c6958f"
  },
  {
    id: 2,
    name: "Times Square",
    position: [40.758896, -73.985130],
    description: "The most bustling square of New York",
    image: "https://images.unsplash.com/photo-1534270804882-6b5048b1c1fc"
  },
  {
    id: 3,
    name: "Empire State Building",
    position: [40.748817, -73.985428],
    description: "An iconic Art Deco skyscraper",
    image: "https://images.unsplash.com/photo-1583842761844-be1a1f32f61d"
  }
];

// Custom icon using Lucide React
const customIcon = new Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

export default function Map() {
  return (
    <MapContainer
      center={[40.7128, -74.0060]}
      zoom={12}
      className="w-full h-[calc(100vh-4rem)]"
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      
      {pointsOfInterest.map((poi) => (
        <Marker 
          key={poi.id}
          position={poi.position as [number, number]}
          icon={customIcon}
        >
          <Popup>
            <div className="max-w-sm">
              <h3 className="text-lg font-semibold mb-2">{poi.name}</h3>
              <img 
                src={poi.image} 
                alt={poi.name}
                className="w-full h-32 object-cover rounded-lg mb-2"
              />
              <p className="text-sm text-gray-600">{poi.description}</p>
            </div>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}